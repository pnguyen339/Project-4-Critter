﻿Data Structure:
	Hashmap – contains all the locations of every Critters in the world

